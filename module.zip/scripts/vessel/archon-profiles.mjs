import {
  AUTOMATION_ROLES,
  MODULE_ID
} from './constants.mjs';
import {
  getAllowedArchonProfilesForActor,
  getArchonProfilesForActor,
  getDireStatureOptions
} from './rules.mjs';

const ARCHON_ROLES = new Set([
  AUTOMATION_ROLES.ARCHON_TRANSFORM_FREE,
  AUTOMATION_ROLES.ARCHON_TRANSFORM_SLOT,
  AUTOMATION_ROLES.ARCHON_EXTEND,
  AUTOMATION_ROLES.ARCHON_REVERT
]);

const TRANSFORM_ROLES = new Set([
  AUTOMATION_ROLES.ARCHON_TRANSFORM_FREE,
  AUTOMATION_ROLES.ARCHON_TRANSFORM_SLOT
]);

const SLOT_ROLES = new Set([
  AUTOMATION_ROLES.ARCHON_TRANSFORM_SLOT,
  AUTOMATION_ROLES.ARCHON_EXTEND
]);

const profileSourceCache = new Map();
const preparationState = new WeakMap();

function documents(collection) {
  if (!collection) return [];
  if (Array.isArray(collection)) return collection;
  return Array.from(collection.values?.() ?? collection);
}

function identifier(item) {
  return item?.identifier ?? item?.system?.identifier;
}

function role(document) {
  return document?.flags?.[MODULE_ID]?.vessel?.role;
}

function objectData(document) {
  return document?.toObject ? document.toObject() : structuredClone(document);
}

function activityProfiles(activity) {
  return documents(activity?.profiles);
}

function isActorDocument(document) {
  return document?.documentName === 'Actor'
    || document?.constructor?.documentName === 'Actor'
    || ['character', 'npc'].includes(document?.type);
}

function error(code, message, details) {
  return new ArchonPreparationError(code, message, details);
}

function validateOwner(activity, actor) {
  if (!actor || actor.isOwner === false || activity?.item?.isOwner === false) {
    throw error(
      'not-owner',
      'You must own this Vessel actor to use its Archon Form controls.'
    );
  }
}

function vesselClass(actor) {
  return actor?.classes?.vessel
    ?? documents(actor?.items).find(candidate =>
      candidate?.type === 'class' && identifier(candidate) === 'vessel'
    );
}

function spellPoolEntries(pools) {
  if (!pools) return [];
  if (typeof pools.entries === 'function') {
    return Array.from(pools.entries());
  }
  return Object.entries(pools);
}

export function resolveVesselSpellSlotPool(actor, {
  spellcasting = globalThis.CONFIG?.DND5E?.spellcasting,
  spellProgression = globalThis.CONFIG?.DND5E?.spellProgression
} = {}) {
  const cls = vesselClass(actor);
  const progression = cls?.system?.spellcasting?.progression;
  const methodKey = cls?.spellcasting?.type
    ?? spellProgression?.[progression]?.type
    ?? progression;
  const model = methodKey ? spellcasting?.[methodKey] : undefined;
  const modelKey = model?.getSpellSlotKey?.();
  const entries = spellPoolEntries(actor?.system?.spells);
  const candidates = [
    modelKey,
    model?.type,
    model?.progression,
    methodKey,
    progression,
    'vessel'
  ]
    .filter((key, index, keys) => key && keys.indexOf(key) === index);

  let resolved = entries.find(([key]) => candidates.includes(key));
  if (!resolved) {
    const matching = entries.filter(([, pool]) =>
      candidates.includes(pool?.type)
    );
    if (matching.length === 1) resolved = matching[0];
  }
  if (!resolved) return;
  const [key, pool] = resolved;
  return {
    key,
    pool,
    target: `spells.${key}.value`
  };
}

function prepareVesselSlotUse(activity, actor, options) {
  const resolved = resolveVesselSpellSlotPool(actor, options);
  const pool = resolved?.pool;
  if (!pool) {
    throw error(
      'missing-vessel-slots',
      'This actor does not have a Vessel Magic spell-slot pool.',
      {
        availablePoolKeys: spellPoolEntries(actor?.system?.spells)
          .map(([key]) => key)
          .filter(key => typeof key === 'string')
      }
    );
  }
  if (!(Number(pool.value) > 0)) {
    throw error(
      'vessel-slots-exhausted',
      'No Vessel Magic spell slots remain.'
    );
  }
  const consumption = objectData(activity.consumption ?? {});
  const target = consumption.targets?.find(candidate =>
    candidate.type === 'attribute'
      && /^spells\.[^.]+\.value$/.test(candidate.target ?? '')
  );
  if (!target) {
    throw error(
      'missing-vessel-slot-target',
      'This Archon Form activity has no Vessel spell-slot consumption target.'
    );
  }
  target.target = resolved.target;
  updateActivity(activity, { consumption });
  return resolved;
}

function updateActivity(activity, changes) {
  if (typeof activity?.updateSource === 'function') {
    activity.updateSource(changes);
    return;
  }
  if (changes.profiles) activity.profiles = structuredClone(changes.profiles);
  if (changes.consumption) {
    activity.consumption = structuredClone(changes.consumption);
  }
}

export class ArchonPreparationError extends Error {
  constructor(code, message, details) {
    super(message);
    this.name = 'ArchonPreparationError';
    this.code = code;
    this.details = details;
  }
}

export function findArchonFormItem(actor) {
  return documents(actor?.items).find(item =>
    identifier(item) === 'archon-form'
      || item?.flags?.[MODULE_ID]?.vessel?.archon?.role === 'archon-resource'
  );
}

export async function promptForDireStature(actor, {
  dialog = globalThis.foundry?.applications?.api?.DialogV2,
  getOptions = getDireStatureOptions
} = {}) {
  const options = getOptions(actor);
  if (options.length === 1) return options[0];
  if (!actor?.isOwner || typeof dialog?.wait !== 'function') return null;

  const buttons = [
    {
      action: 'normal',
      label: 'Normal',
      callback: () => 0
    },
    {
      action: 'large',
      label: 'Large',
      callback: () => 1
    }
  ];
  if (options.includes(2)) {
    buttons.push({
      action: 'huge',
      label: 'Huge',
      callback: () => 2
    });
  }
  buttons.push({
    action: 'cancel',
    label: 'Cancel',
    callback: () => null
  });
  return dialog.wait({
    window: { title: 'Dire Stature' },
    content: [
      '<p>Choose the size of your Archon Form.</p>',
      '<p>Confirm that there is room for your Archon Form to grow before choosing Large or Huge.</p>'
    ].join(''),
    buttons,
    close: () => null
  });
}

export async function resolveArchonProfileSources(profiles, {
  resolveUuid = globalThis.fromUuid,
  cache
} = {}) {
  if (typeof resolveUuid !== 'function') {
    throw error(
      'profile-pack-unavailable',
      'The Archon Form Actor compendium is unavailable.'
    );
  }

  const sourceCache = cache
    ?? (resolveUuid === globalThis.fromUuid ? profileSourceCache : new Map());
  const resolved = [];
  for (const profile of profiles) {
    const uuid = profile?.uuid;
    if (!uuid) {
      throw error(
        'missing-profile-uuid',
        `The ${profile?.profile ?? 'selected'} Archon profile has no Actor UUID.`
      );
    }

    let request = sourceCache.get(uuid);
    if (!request) {
      request = Promise.resolve().then(() => resolveUuid(uuid));
      sourceCache.set(uuid, request);
    }

    let source;
    try {
      source = await request;
    } catch (cause) {
      if (sourceCache.get(uuid) === request) sourceCache.delete(uuid);
      throw error(
        'profile-pack-unavailable',
        `The Archon profile compendium could not be loaded for ${profile.profile}.`,
        { uuid, cause }
      );
    }
    if (!isActorDocument(source)) {
      if (sourceCache.get(uuid) === request) sourceCache.delete(uuid);
      throw error(
        'missing-profile-actor',
        `The Actor for the ${profile.profile} Archon profile is missing.`,
        { uuid }
      );
    }
    resolved.push(source);
  }
  return resolved;
}

function filterTransformProfiles(activity, actor, usageConfig) {
  const allowed = getAllowedArchonProfilesForActor(actor);
  const preferred = getArchonProfilesForActor(actor);
  const allowedUuids = new Set(allowed.map(profile => profile.uuid));
  const current = activityProfiles(activity);
  const filtered = current.filter(profile => allowedUuids.has(profile.uuid));

  if (!filtered.length) {
    throw error(
      'no-allowed-profile',
      'This Archon Form control does not contain a profile for the actor’s Sealed Spirit.'
    );
  }

  const selected = usageConfig?.transform?.profile;
  const selectedAllowed = !selected
    || filtered.some(profile => (profile.id ?? profile._id) === selected);
  if (!selectedAllowed) {
    throw error(
      'invalid-profile-selection',
      'The selected Archon profile does not belong to this actor’s Sealed Spirit.'
    );
  }

  const serialized = filtered.map(objectData);
  updateActivity(activity, { profiles: serialized });
  const preferredUuid = preferred.length === 1 ? preferred[0].uuid : undefined;
  const preferredProfile = preferredUuid
    ? serialized.find(profile => profile.uuid === preferredUuid)
    : undefined;
  if (preferredProfile || serialized.length === 1) {
    usageConfig.transform ??= {};
    usageConfig.transform.profile =
      (preferredProfile ?? serialized[0])._id
      ?? (preferredProfile ?? serialized[0]).id;
  }
  const allowedByUuid = new Map(allowed.map(profile => [profile.uuid, profile]));
  return filtered.map(profile => allowedByUuid.get(profile.uuid));
}

function prepareFreeUse(activity, actor) {
  const resourceItem = findArchonFormItem(actor);
  if (!resourceItem) {
    throw error(
      'missing-archon-resource',
      'The Archon Form class feature is missing from this actor.'
    );
  }

  const uses = resourceItem.system?.uses;
  const maximum = Number(uses?.max);
  const spent = Number(uses?.spent) || 0;
  if (Number.isFinite(maximum) && maximum > 0 && spent >= maximum) {
    throw error(
      'free-use-exhausted',
      'The free Archon Form use has already been spent.'
    );
  }

  const consumption = objectData(activity.consumption ?? {});
  const target = consumption.targets?.find(candidate =>
    candidate.type === 'itemUses'
  );
  if (!target) {
    throw error(
      'missing-free-use-target',
      'The free Archon Form activity has no item-use consumption target.'
    );
  }
  target.target = resourceItem.id ?? resourceItem._id;
  if (!target.target) {
    throw error(
      'missing-archon-resource-id',
      'The owned Archon Form feature has no embedded Item ID.'
    );
  }
  updateActivity(activity, { consumption });
  return resourceItem;
}

export async function prepareArchonActivityUse(activity, usageConfig = {}, {
  resolveUuid = globalThis.fromUuid,
  cache,
  promptForDireStature: chooseDireStature = promptForDireStature,
  spellcasting = globalThis.CONFIG?.DND5E?.spellcasting,
  spellProgression = globalThis.CONFIG?.DND5E?.spellProgression
} = {}) {
  const activityRole = role(activity);
  if (!ARCHON_ROLES.has(activityRole)) return { handled: false };

  const actor = activity?.item?.actor;
  validateOwner(activity, actor);

  if (TRANSFORM_ROLES.has(activityRole)) {
    const growthCategories = await chooseDireStature(actor);
    if (growthCategories == null) return { handled: true, cancelled: true };
    usageConfig.growthCategories = growthCategories;
  }

  let resourceItem;
  if (activityRole === AUTOMATION_ROLES.ARCHON_TRANSFORM_FREE) {
    resourceItem = prepareFreeUse(activity, actor);
  } else if (SLOT_ROLES.has(activityRole)) {
    prepareVesselSlotUse(activity, actor, { spellcasting, spellProgression });
  }

  let profileSources = [];
  let profiles = [];
  if (TRANSFORM_ROLES.has(activityRole)) {
    profiles = filterTransformProfiles(activity, actor, usageConfig);
    profileSources = await resolveArchonProfileSources(profiles, {
      resolveUuid,
      cache
    });
  }

  return {
    handled: true,
    ...(resourceItem ? { resourceItem } : {}),
    profiles,
    profileSources
  };
}

function preparationKey(activity) {
  return [
    activity?.item?.id ?? activity?.item?._id ?? '',
    activity?.id ?? activity?._id ?? '',
    role(activity) ?? ''
  ].join(':');
}

function stateForActor(state, actor) {
  let entries = state.get(actor);
  if (!entries) {
    entries = new Map();
    state.set(actor, entries);
  }
  return entries;
}

function preparedPayload(activity, usageConfig) {
  return {
    profiles: activityProfiles(activity).map(objectData),
    consumption: objectData(activity.consumption ?? {}),
    selectedProfile: usageConfig?.transform?.profile,
    growthCategories: usageConfig?.growthCategories
  };
}

function applyPreparedPayload(activity, usageConfig, payload) {
  updateActivity(activity, {
    profiles: payload.profiles,
    consumption: payload.consumption
  });
  if (payload.selectedProfile) {
    usageConfig.transform ??= {};
    usageConfig.transform.profile = payload.selectedProfile;
  }
  if (payload.growthCategories != null) {
    usageConfig.growthCategories = payload.growthCategories;
  }
}

/**
 * Bridge dnd5e's synchronous pre-use hook to the asynchronous compendium
 * preflight. The first call cancels native use and resolves the profile Actors.
 * The guarded retry applies the prepared clone data synchronously and proceeds.
 */
export function requestArchonActivityPreparation(activity, usageConfig = {}, {
  state = preparationState,
  prepareUse = prepareArchonActivityUse,
  retry,
  onError = error => console.error(
    "Declan's Homebrew Classes | Archon preparation failed.",
    error
  ),
  ...prepareOptions
} = {}) {
  if (!ARCHON_ROLES.has(role(activity))) return;

  const actor = activity?.item?.actor;
  const stateOwner = actor ?? activity?.item ?? activity;
  const entries = stateForActor(state, stateOwner);
  const key = preparationKey(activity);
  const existing = entries.get(key);
  if (existing?.status === 'ready') {
    entries.delete(key);
    applyPreparedPayload(activity, usageConfig, existing.payload);
    return;
  }
  if (existing?.status === 'pending') return false;

  const entry = { status: 'pending' };
  entries.set(key, entry);
  entry.promise = Promise.resolve()
    .then(() => prepareUse(activity, usageConfig, prepareOptions))
    .then(result => {
      if (entries.get(key) !== entry) return;
      if (result?.cancelled) {
        entries.delete(key);
        return;
      }
      entry.status = 'ready';
      entry.payload = preparedPayload(activity, usageConfig);
      return retry?.(activity);
    })
    .catch(failure => {
      if (entries.get(key) === entry) entries.delete(key);
      onError(failure);
    })
    .finally(() => {
      if (entries.get(key) === entry && entry.status === 'ready') {
        entries.delete(key);
      }
    });
  return false;
}
